This is for checking the how the output will looks like for arithmatic expression only.
- write some arithmatic expression in the file named "in.txt"
- now double click on the "code_gen.exe" 
- it will generate two file
	- "code.asm" file 
	- and "code.ir" file
